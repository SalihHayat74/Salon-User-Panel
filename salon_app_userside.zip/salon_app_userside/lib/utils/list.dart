List<String> technicianImageList = [
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6q-OlR7WntDLlEFoZYZHQoutvJ6TpOi9lcA&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzSGNHM46MfGzApqtGdTOSQDeR93Cc-0_wvg&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0EBwVnsTlqP6bQ66ERphsMZwHAR--9TvOvw&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgqm5S5w6YLiGK2AWtwvxqBp6MVRGszKWPMg&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVNA_vThyTMqcqJi1izqOC7r0n5IOushakxEul9sncBpoovlbQ6uz_rlow75qfUId5lCA&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRd8q4JCaG4zSQv5WEbAcO7m5qMLf-OeFYCYg&usqp=CAU',
];
List<String> technicianNames = [
  "Technician 1",
  "Technician 2",
  "Technician 3",
  "Technician 4",
  "Technician 5",
  "Technician 6",
];
List<String> nailPolishImages = [
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQhZbfBlyeZrO_itj_RFZU4sarBOJSvrrGag&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGFeXKMcJbrYLc-b2EK4j0oP0XwD_JFLAa3A&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR40_csZ_PsZp4MLUchwNSdkEXURKNTeP__4g&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVEC24cdpfztqBCbrqgOp9B0goX0yMcWJiUA&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_hQ-g2oz-fvBrDuIc6Ml9gakM6X2xNZdBXg&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6uWlx3JNNbb4JnaRlnU-8yI3XP1DLK7smcg&usqp=CAU',
];
List<String> nailPolishNames = [
  "Essie",
  "Big Apple Red",
  "Gelcolor",
  "Deborah Lippmann",
  "Bling nail Polish",
  "ZigZag Nails",
];
