




class FirestoreConstants{
  static const String technicianCollection="technicians";
  static const String appointmentsCollection="appointments";
  static const String appointmentTimesCollection="appointmentTimes";
  static const String productsCollection="products";
  static const String servicesCollection="services";
  static const String deviceTokensCollection="device tokens";
  static const String usersCollection="users";
}